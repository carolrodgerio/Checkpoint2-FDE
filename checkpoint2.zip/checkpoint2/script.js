const buttonNumbers = document.getElementsByName('numeros'); /* numeros es classs */
const buttonOperations = document.getElementsByName('operadores');
const buttonEqual = document.getElementsByName('igual')[0];
const buttonDelete = document.getElementsByName('deletar')[0];
var result = document.getElementById('result');
var currentOperator = '';
var previousOperator = '';
var operation = undefined;

buttonNumbers.forEach(function(button){
    button.addEventListener('click', function(){
        addNumber(button.innerText);        
    })
});

buttonOperations.forEach(function(button){
    button.addEventListener('click', function(){
        selectoperation(button.innerText);        
    })
});

buttonEqual.addEventListener('click', function(){
    calculate();
    updateDIsplay();
});

buttonDelete.addEventListener('click', function(){
    clear();
    updateDIsplay();
});

function selectoperation(op){
    if(currentOperator === '') return;
    if(previousOperator !== ''){
        calculate()
    }
    operation = op.toString();
    previousOperator = currentOperator;
    currentOperator = '';
}

function calculate(){
    var calculation;
    const previous = parseFloat(previousOperator);
    const current = parseFloat(currentOperator);
    if(isNaN(previous) || isNaN(current)) return;
    switch(operation){
        case '+':
            calculation = previous + current;
            break;
        case '-':
            calculation = previous - current;
            break;
        case 'x':
            calculation = previous * current;
            break;
        case '/':
            calculation = previous / current;
            break;
        default:
            return;
    }
    currentOperator = calculation;
    operation = undefined;
    previousOperator = '';
}

function addNumber(num){
    currentOperator = currentOperator.toString() + num.toString();
    updateDIsplay();
}

function clear(){
    currentOperator = '';
    previousOperator = '';
    operation = undefined;
}

function updateDIsplay(){
    result.value = currentOperator;
}

clear();

